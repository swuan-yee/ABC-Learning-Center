package CompanyStructure;

public abstract class Employee {
    String name;
    double baseSalary;
    int employeeID;
    int countID;
    public double bonusBudget;
    public double bonus;
    private static int countEmployee;
    public Employee manager;
    public Accountant accountantSupport;
    public int headcount = 0;



    /*construct a new employee object and take in two parameters,
      one for the name of the user and for their base salary */
    public Employee(String name, double baseSalary) {
        this.name = name;
        this.baseSalary = baseSalary;
        countEmployee ++;
        this.employeeID = countEmployee;
    }

    public Employee(String name) {
        this.name = name;
        countEmployee ++;
        this.employeeID = countEmployee;
    }

    public Accountant getAccountantSupport(){
        return  this.accountantSupport;
    }


    //return the employee's current salary
    public double getBaseSalary() {
        return this.baseSalary;
    }


    //return the employee at the time they are constructed
    public String getName() {
        return this.name;
    }

    public int getEmployeeID() {

        return this.employeeID;
    }

    public Employee getManager() {
        return manager;
    }

    public void setManager(Employee manager) {
        this.manager = manager;
    }

    //return true if the two employee ID are the same, false otherwise
    public boolean equals(Employee other) {
        if(this.employeeID == other.employeeID)
            return true;
        else
            return false;
    }


    /* return a String representation of the employee that is a combination of their
       id followed by their name */
    @Override
    public String toString() {
        return "Employee { " +
                "employeeID = " + employeeID +
                " name = '" + name + '\'' +
                '}';
    }

    public abstract String employeeStatus();
    public void getBonus(){

    }

    public abstract boolean approveBonus(int i);
}
