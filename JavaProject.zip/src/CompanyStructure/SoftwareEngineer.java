package CompanyStructure;

public class SoftwareEngineer extends TechnicalEmployee{
    public boolean CodeAccess;

    public SoftwareEngineer(String name){
        super (name);
        setCodeAccess (true);

    }
    //return whether or not this SoftwareEngineer has access for make changes to the code base
    public boolean getCodeAccess(){
        return CodeAccess;
    }

    //an external piece of code to update the SoftwareEngineer's code privileges to either true or false
    public void setCodeAccess(boolean access){
        this.CodeAccess = access;
    }

    //return the current count of how many times this SoftwareEngineer has successfully checked in code
    public int getSuccessfulCheckIns (){
        return checkIn;
    }

    /* if this SoftwareEngineer's manager approves of their check in. It the check in is approved
    their successful checkin count should be increased and the method should return "true". If the manager
    does not approve the check in the SoftwareEngineer's code access should be changed to false and the method should
    return  "false". */

    public boolean checkInCode(){
        TechnicalLead manager = (TechnicalLead) this.getManager();
        if (manager.approveCheckIn(this)){
            this.checkIn++;
            return true;
        }
        else {
            CodeAccess = false;
            return false;
        }
    }

}
