package CompanyStructure;

public class TechnicalEmployee extends Employee {
    int checkIn;
    public TechnicalEmployee(String name) {
        super(name,75000.00); //has a default base salary of 75000
        checkIn++;
    }


    /* return a String representation of this TechnicalEmployee that includes their ID,
     name and how many successful check ins they have had (Eg. 1 Kasey has 10 successful check ins.) */
    @Override
    public String employeeStatus() {
        return (employeeID + name + " has " + checkIn + " successful check ins.").toString();
    }

    @Override
    public boolean approveBonus(int i) {
        return false;
    }
}