package CompanyStructure;

public class BusinessEmployee extends Employee{

    public BusinessEmployee(String name, double baseSalary) {
                    //default salary of 50000
        super(name, 50000.00);
    }

    public BusinessEmployee(String name) {
        super(name, 50000.00);

    }




    /* establish a running tally of the remaining bonusBudget for the team this employee supports.
      How that budget is determined will depend on which type of business employee */
    public double getBonusBudget(){

        return bonusBudget;
    }

    public void setBonusBudget (double bonusBudget){

        this.bonusBudget = bonusBudget;
    }


    /* return a String representation of this BusinessEmployee that include their
    ID, name and the size of their currently managed budget (eg. 1 Kasey with a budget of 22500.0) */
    public String employeeStatus(){
        //to reduce the double 2 decimals
        String s = String.format("%.2f ", bonusBudget );
        return this.toString() + " with a budget of " + s;
    }

    @Override
    public boolean approveBonus(int i) {
        return false;
    }
}
