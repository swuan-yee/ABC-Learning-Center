package CompanyStructure;

import org.junit.Test;

import static org.junit.jupiter.api.Assertions.*;

class CompanyStructureTest {

    @org.junit.jupiter.api.Test
    void testCase1() {

            System.out.println("Test Case Number 1");
            System.out.println("Software Engineer can check code?");
            TechnicalLead l = new TechnicalLead("Satya");
            SoftwareEngineer s = new SoftwareEngineer("Kasey");
            s.setCodeAccess(false);
            l.addReport(s);
            boolean actualResult = s.getCodeAccess();
            assertEquals(false, actualResult);
            System.out.println("Expected Result is " + false);
            System.out.println("Actual Result is " + actualResult);
        }
    @org.junit.jupiter.api.Test
    void testCase2() {

        System.out.println("Test Case Number 1");
        System.out.println("Software Engineer can check code?");
        TechnicalLead l = new TechnicalLead("Satya");
        SoftwareEngineer s = new SoftwareEngineer("Kasey");
        s.setCodeAccess(true);
        l.addReport(s);
        boolean actualResult = s.getCodeAccess();
        assertEquals(true, actualResult);
        System.out.println("Expected Result is " + true);
        System.out.println("Actual Result is " + actualResult);
    }

    @org.junit.jupiter.api.Test
    void testCase3(){
        System.out.println("Test Case Number 3");
        System.out.println("Accountant can approve bonus?");
        BusinessLead l = new BusinessLead("Amy Hood");
        Accountant ac = new Accountant("Niky");
        TechnicalLead t = new TechnicalLead("Satya");
        l.addReport(ac,t);
        boolean actualResult = ac.approveBonus(20000000);
        assertEquals(false, actualResult);
        System.out.println("Expected Result is " + false);
        System.out.println("Actual Result is " + actualResult);
    }
    @org.junit.jupiter.api.Test
    void testCase4(){
        System.out.println("Test Case Number 4");
        System.out.println("Accountant can approve bonus?");
        BusinessLead l = new BusinessLead("Amy Hood");
        Accountant ac = new Accountant("Niky");
        TechnicalLead t = new TechnicalLead("Satya");
        l.addReport(ac,t);
        boolean actualResult = ac.approveBonus(1000);
        assertEquals(true, actualResult);
        System.out.println("Expected Result is " + true);
        System.out.println("Actual Result is " + actualResult);
    }
    //testCase5 is pass
    @org.junit.jupiter.api.Test
    void testCase5(){
        System.out.println("Test Case Number 5");
        System.out.println("Software Engineer can get bonus?");
        BusinessLead bl = new BusinessLead("Amy Hood");
        Accountant a = new Accountant("Niky");
        TechnicalLead l = new TechnicalLead("Satya");
        SoftwareEngineer s = new SoftwareEngineer("Kasey");
        l.addReport(s);
        bl.addReport(a,l);
        boolean actualResult = bl.requestBonus(s,20000000);
        assertEquals(false, actualResult);
        System.out.println("Expected Result is " + false);
        System.out.println("Actual Result is " + actualResult);
    }


    @org.junit.jupiter.api.Test
    void testCase6(){
        System.out.println("Test Case Number 6");
        System.out.println("Software Engineer can get bonus?");
        BusinessLead bl = new BusinessLead("Amy Hood");
        Accountant a = new Accountant("Niky");
        TechnicalLead l = new TechnicalLead("Satya");
        SoftwareEngineer s = new SoftwareEngineer("Kasey");
        l.addReport(s);
        bl.addReport(a,l);
        boolean actualResult = bl.requestBonus(s,1000);
        assertEquals(true, actualResult);
        System.out.println("Expected Result is " + true);
        System.out.println("Actual Result is " + actualResult);
    }


}
