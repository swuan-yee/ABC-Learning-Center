package CompanyStructure;

public class Accountant extends BusinessEmployee{
    public TechnicalEmployee teamSupported;

    //start with a bonus budget of 0 and no team they are officially supporting
    public Accountant (String name){
        super(name);
        bonusBudget = 0;

    }

    /* return a reference to the TechnicalLead that this Accountant is currently supporting.
    if they have not been assigned a TechnicalLead null should be returned
     */

    public TechnicalEmployee getTeamSupported(){
        return teamSupported;
    }

    /* allow a reference to a TechnicalLead to be passed in and saved.
    once this happens the Accountant's bonus budget should be updated to be the total of each SoftwareEngineer's base
    salary that reports to that TechnicalLead plus 1o%
     */

    public void supportTeam (TechnicalLead lead){
        this.teamSupported = lead;
        for (int i=0; i<lead.team.size(); i++){
            this.bonusBudget+=lead.team.get(i).getBaseSalary()*1.1;
        }

    }

    /* Should take in a suggested bonus amount and check if there is still enough room in the budget.
    If the bonus is greater than the remaining budget, false should be returned, otherwise true.
    If the accountant is not supporting any team false should be returned. */
    public boolean canApproveBonus(double bonus){
        double requestedBonus=bonus;
        if (requestedBonus<=getBonusBudget()){
            return true;
        } else {
            System.out.print(" Rejected because Budget not sufficient. ");
            return false;
        }

    }

    /* return a String representation of this Accountant that includes their ID, name,
    the size of their currently managed budget and the name of the TechnicalLead they are currently supporting.
    Eg: 1 Kasey with a budget of 22500.0 is supporting Satya Nadella */
    public String employeeStatus(){
        return this.toString()+" with a budget of "+ getBonusBudget()+" is supporting "+ this.getTeamSupported();
    }

}
